import pandas as pd

"""
data explain
[student(0), sex(1), class(2), kor_score(3), eng_score(4), math_score(5)]
"""
#data read to text file
def read_data():
    try:
        with open("score_table.txt", "r", encoding="utf-8") as f:
            lines = f.readlines()
    except:
        with open("score_table.txt", "r", encoding="cp949") as f:
            lines = f.readlines()
    students = []
    for info in lines:
        tmp = []
        info = info.replace("\n","").split()
        #string to number
        for component in info:
            try:
                tmp.append(int(component))
            except:
                tmp.append(component)
        
        students.append(tmp)
    return students

#data read to excel file
def read_data_excel():
    df = pd.read_excel("score_table.xlsx",encoding="utf-8")
    students = []
    for idx in df.index:
        tmp = []
        for info in df.loc[idx]:
            try:
                tmp.append(int(info))
            except:
                tmp.append(info)
        students.append(tmp)
    return students

#data read to excel file_class
def class_table(class_num, engine="txt"):
    """
    class_num : class number[1,2,3,4,5,6,7,8,9,10]
    engine : data read way. ["txt","excel"]
    """
    if engine == "txt":
        data = read_data()
    elif engine == "excel":
        data = read_data_excel()
    else:
        return None
    #class classification
    class_student = []
    for student in data:
        if student[2] == class_num:
            class_student.append(student)
    return class_student

#list change to str
def list_to_str(ls, mode="single"):
    """
    list change to str. if mode is 'single(default)', only single list change to str.
    if mode is 'multi', multi_list change to str, and lines combine with enter.
    ls : list
    mode : ["single", "multi"]
    """
    
    if mode=="single":
        for idx, _ in enumerate(ls):
            ls[idx] = str(ls[idx])
        return " ".join(ls)
    
    elif mode=="multi":
        txt = ""
        for student in ls:
            for idx, _ in enumerate(student):
                student[idx] = str(student[idx])
            txt += ",".join(student) + "\n"
        return txt
    else:
        print(f"{mode} mode is Not Found")
        return ls